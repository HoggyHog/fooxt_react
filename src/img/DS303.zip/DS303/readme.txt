Decoding the Black Box: Evaluating XAI with Machine Learning

Course Project - DS 303 - Machine Learning - Spring Semester 2023

Abstract — The goal of this study is to use XAI methods to try and 
increase the explainability of black-box models such as Artificial Neural Networks, 
Random Forests and LightGBM. After that, we also try to prove its effectiveness using
an evaluation framework and also go on to describe which method works best for a model. 
This project is the code implementation of the research paper "XAI Evaluation: Evaluating Black-Box Model
Explanations for Prediction" 

System Requirements: 
- ```python 3.x```
- ```pandas, matplotlib, numpy, tensorflow, sklearn```

Extra dependencies to be installed:
- pip install shap
- pip install lime

Description:
- DS 3030 PROJECT REPORT.ppt file contains the explanation of the project, and the contribution of each team member in the last slide
- The DS303_COURSE_PROJECT_LightBGM.ipynb file contains the entire source code of the project, and while doing the analysis for LBGM model
- The DS303_COURSE_PROJECT_RF.ipynb file contains the entire source code of the project, and while doing the analysis for RF model
- Customer Churn.csv is the dataset we used
- The research paper is also enclosed


Contributors
- Karthikeyan J
- Vishesh Kamani
- Akash Sansugu Palaniswami
- Karthik Sood 